<?php

$config["protocol"] = "smtp";
$config["smtp_host"] = "da02.tipcon.nl";
$config["smtp_user"] = "noreply@tipcon.nl";
$config["smtp_pass"] = "jxOSACV0";
$config["smtp_port"] = "587";

$config["wordwrap"] = TRUE;
$config["wrapchars"] = 76;
$config["mailtype"] = "html";
$config["from_email"] = "intern@tipcon.nl";
$config["from_name"] = "Tipcon Intern";
?>
