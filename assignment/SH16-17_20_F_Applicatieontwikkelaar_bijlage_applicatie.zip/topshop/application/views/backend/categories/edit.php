<h2>Categorie Bewerken</h2>
<form method="post" action="index.php/backend/categories/edit_save/">
	<div class="form-group">
		<label for="title">Titel</label>
		<input type="text" id="title" name="title" class="form-control" placeholder="Titel" value="<?=$category["title"]?>">
	</div>
	<div class="form-group">
		<label for="url">URL</label>
		<input type="text" id="url" name="url" class="form-control" placeholder="URL" value="<?=$category["url"]?>">
	</div>
	<div class="form-group">
		<label for="description">Omschrijving</label>
		<textarea id="description" name="description" class="form-control" placeholder="Omschrijving" rows="5"><?=$category["description"]?></textarea>
	</div>
	<div class="form-group">
		<input type="hidden" name="id" value="<?=$category["id"]?>" />
		<button type="submit" class="btn btn-primary">Opslaan</button>
	</div>
</form>
