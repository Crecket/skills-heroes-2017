<h2>Categorieën</h2>
<a href="index.php/backend/categories/add" class="btn btn-primary btn-xs">
	<i class="fa fa-plus"></i> Toevoegen
</a>
<hr />
<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th>Plaats</th>
			<th>Acties</th>
		</tr>
	</thead>
	<tbody>
		<? foreach($categories as $category): ?>
		<tr>
			<td><?=$category["title"]?></td>
			<td>
				<a href="index.php/backend/categories/edit/<?=$category["id"]?>" class="btn btn-primary btn-xs">
					<i class="fa fa-pencil"></i> Bewerken
				</a>
			</td>
		</tr>
		<? endforeach; ?>
	</tbody>
</table>