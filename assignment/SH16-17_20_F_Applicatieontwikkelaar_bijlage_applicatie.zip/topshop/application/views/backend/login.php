<div class="row">
	<div class="col-md-4 col-md-offset-4">
		<form method="post" action="index.php/backend/login/check/">
			<div class="form-group">
				<label for="password">Wachtwoord</label>
				<input type="password" name="password" class="form-control" id="password" placeholder="Wachtwoord">
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-primary btn-block">Inloggen</button>
			</div>
		</form>
	</div>
</div>