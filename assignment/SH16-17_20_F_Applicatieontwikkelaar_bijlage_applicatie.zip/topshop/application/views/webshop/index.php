<h2>Webshop</h2>
<p>Selecteer een categorie:</p>

<div class="row">
	<? foreach($categories as $category): ?>
	<div class="col-md-4">
		<a href="index.php/webshop/category/<?=$category["url"]?>/"><b><?=$category["title"]?></b></a>
		<p><?=$category["description"]?></p>
	</div>
	<? endforeach; ?>
</div>