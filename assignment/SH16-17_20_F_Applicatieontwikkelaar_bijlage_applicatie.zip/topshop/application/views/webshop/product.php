<h2><?=$product["name"]?></h2>
<div class="row">
	<div class="col-md-4">
		<img src="files/products/<?=$product["id"]?>.jpg" class="img img-thumbnail product-photo" />
	</div>
	<div class="col-md-8">
		<p><?=$product["description"]?></p>
		<table class="table">
			<tr>
				<td>Categorie:</td>
				<td><a href="index.php/webshop/category/<?=$category["url"]?>/"><?=$category["title"]?></a></td>
			</tr>
			<tr>
				<td>EAN:</td>
				<td><?=$product["ean"];?></td>
			</tr>
			<tr>
				<td>Prijs:</td>
				<td>&euro; <?=number_format($product["price"], 2, ",", ".")?></td>
			</tr>
		</table>
		<a href="#" class="btn btn-info"><i class="fa fa-shopping-cart"></i> Winkelwagen</a>
	</div>
</div>
