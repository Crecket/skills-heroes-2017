<h2>Contact</h2>
<p><a href="mailto:info@topshop.nl"><i class="fa fa-envelope"></i> info@topshop.nl</a><br />
<i class="fa fa-phone"></i> 088 123 456 78</p>

<h3><i class="fa fa-compass"></i> Winkels</h3>

<table class="table">
	<thead>
		<tr>
			<th>Plaats</th>
			<th>Adres</th>
			<th>Openingstijden</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>Amsterdam</td>
			<td>Kalverstraat 21</td>
			<td>
				Ma-Do: 09:00 - 18:00<br />
				Vr: 09:00 - 21:00<br />
				Za: 09:00 - 18:00<br />
			</td>
		</tr>
		<tr>
			<td>Groningen</td>
			<td>Herestraat 32</td>
			<td>
				Ma-Do: 09:00 - 18:00<br />
				Vr: 09:00 - 21:00<br />
				Za: 09:00 - 18:00<br />
			</td>
		</tr>
		<tr>
			<td>Rotterdam</td>
			<td>Korte Hoogstraat 13</td>
			<td>
				Ma-Do: 09:00 - 18:00<br />
				Vr: 09:00 - 21:00<br />
				Za: 09:00 - 18:00<br />
			</td>
		</tr>
	</tbody>
</table>