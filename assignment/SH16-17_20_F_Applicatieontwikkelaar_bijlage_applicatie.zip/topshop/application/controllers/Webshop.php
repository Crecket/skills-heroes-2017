<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Webshop extends CI_Controller
{
	public function __construct()
	{
		// Construct parent
		parent::__construct();

    	// Load Category model
    	$this->load->model("category");
    	$this->load->model("product");
	}

    public function index()
    {
        // Load view

        $this->load->view("template", array(
            "page_title"  => "Webshop",
            "view"        => "webshop/index",
            "categories"  => $this->category->get_categories()
        ));
    }

    public function category($category_url)
    {
    	// Get current category
    	$category = $this->category->get_by_url($category_url);

    	if(!is_array($category))
    	{
    		show_error("Couldn't find category");
    	}

        // Load view
        $this->load->view("template", array(
            "page_title"  => "Webshop > Categorie > {$category["title"]}",
            "view"        => "webshop/category",
            "category"    => $category,
            "products"    => $this->product->get_for_category($category["id"]),
        ));
    }

    public function product($product_url)
    {
    	// Get current product
    	$product = $this->product->get_by_url($product_url);

    	if(!is_array($product))
    	{
    		show_error("Couldn't find product");
    	}

        // Load view
        $this->load->view("template", array(
            "page_title"  => "Webshop > Product > {$product["name"]}",
            "view"        => "webshop/product",
            "product"     => $product,
            "category"    => $this->category->get_by_id($product["category_id"]),
        ));
    }
}
