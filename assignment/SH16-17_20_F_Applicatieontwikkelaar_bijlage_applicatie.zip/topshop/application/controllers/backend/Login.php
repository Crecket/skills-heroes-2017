<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function index()
    {
        // Load view
        $this->load->view("backend/template", array(
            "page_title"  => "Inloggen",
            "view"        => "backend/login",
        ));
    }

    public function check()
    {
    	$password = $this->input->post("password");

    	// TODO: Improve this in the future
    	if($password == "test")
    	{
    		$_SESSION["logged_in"] = true;

			redirect("index.php/backend/");
    	}
    	else
    	{
    		redirect("index.php/backend/login");
    	}
    }

    public function logout()
    {
        unset($_SESSION["logged_in"]);
        
        redirect("index.php/backend/");
    }
}
