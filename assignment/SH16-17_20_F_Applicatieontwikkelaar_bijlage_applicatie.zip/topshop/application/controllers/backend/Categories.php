<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Categories extends Sessioned_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model("category");
    }

    public function index()
    {
        // Load view
        $this->load->view("backend/template", array(
            "page_title"  => "Categorieën",
            "view"        => "backend/categories/overview",
            "categories"  => $this->category->get_categories()
        ));
    }

    public function add()
    {
        // Load view
        $this->load->view("backend/template", array(
            "page_title"  => "Categorie Toevoegen",
            "view"        => "backend/categories/add",
        ));
    }

    public function add_save()
    {
        $title = $this->input->post("title");
        $url = $this->input->post("url");
        $description = $this->input->post("description");

        $add = $this->category->add($title, $url, $description);

        redirect("index.php/backend/categories/");
    }

    public function edit($id)
    {
        // Get category
        $category = $this->category->get_by_id($id);

        if(!is_array($category))
        {
            show_error("Couldn't find category");
        }

        // Load view
        $this->load->view("backend/template", array(
            "page_title"  => "Categorie Bewerken",
            "view"        => "backend/categories/edit",
            "category"    => $category
        ));
    }

    public function edit_save()
    {
        $id = $this->input->post("id");
        $title = $this->input->post("title");
        $url = $this->input->post("url");
        $description = $this->input->post("description");

        $edit = $this->category->edit($id, $title, $url, $description);

        redirect("index.php/backend/categories/");
    }
}
