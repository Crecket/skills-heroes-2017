<?php

class Product extends CI_Model
{
    public function get_by_url($url)
    {
        $query = $this->db->query("SELECT `id`,`category_id`,`name`,`url`,`description`,`ean`,`price` FROM `products` WHERE `url` = '$url'");

        if($query->num_rows() == 1)
        {
            return $query->row_array();
        }
        else
        {
            return;
        }
    }

    public function get_for_category($category_id)
    {
        $products = array();

        $query = $this->db->query("SELECT `id`,`name`,`url`,`description`,`price` FROM `products` WHERE `category_id` = $category_id ORDER BY `name`");
        foreach($query->result() as $product)
        {
            $products[$product->id] = array(
                "id" => $product->id,
                "name" => $product->name,
                "url" => $product->url,
                "description" => $product->description,
                "price" => $product->price
            );
        }

        return $products;
    }
}