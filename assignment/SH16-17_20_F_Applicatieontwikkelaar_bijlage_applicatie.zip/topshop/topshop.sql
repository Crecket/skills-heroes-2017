-- phpMyAdmin SQL Dump
-- version 4.4.14.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 12, 2016 at 03:01 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--

--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` text,
  `description` text
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `url`, `description`) VALUES
(1, 'City', 'city', 'LEGO® City is een realistische LEGO wereld waarin je kind van alles kan ontdekken en waarin de verbeelding wordt gestimuleerd. Iconische voertuigen en gebouwen zorgen voor een bruisende omgeving.'),
(2, 'Classic', 'classic', 'Laat kinderen hun creativiteit ontplooien met LEGO® Classic. Sets bieden ideeën waarmee ze aan de slag kunnen en ze zijn leuk voor de hele familie!'),
(3, 'Creator', 'creator', 'Met de LEGO® Creator serie kan je kind eindeloos experimenteren met huizen, auto''s, vliegtuigen en wezens! Elke set kan op drie verschillende manieren worden gebouwd voor onbeperkt speelplezier.'),
(4, 'Ideas', 'ideas', 'Producten van LEGO® Ideas zijn geïnspireerd en gekozen door LEGO fans. De sets omvatten originele concepten en scènes die gebaseerd zijn op de films!'),
(5, 'Marvel Super Heroes', 'marvel-super-heroes', 'Met LEGO® Marvel Super Heroes wekt je kind superhelden tot leven. Ze zullen genieten van het bedenken van nieuwe avonturen voor de gekke personages.');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL,
  `category_id` varchar(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `description` text,
  `ean` varchar(13) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `url`, `description`, `ean`, `price`) VALUES
(1, '1', '7280 Rechte wegenplaten en kruising', '7280-rechte-wegenplaten-en-kruising', 'LEGO City rechte wegenplaat met kruising om een echte LEGO City stad te maken.', '5702015398749', '9.99'),
(2, '1', '7281 T-Kruising en bocht', '7281-t-kruising-en-bocht', 'LEGO City T-kruising en bocht om een echte LEGO City stad te maken.', '5702015398756', '9.99');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD FULLTEXT KEY `price` (`price`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
