

De backend is aan te roepen via /index.php/backend/

Indien je gebruikt maakt van een host name dan dien je die in te stellen in de config Application/config/config.php in de variable $config['base_url'] 